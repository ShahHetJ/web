# ShopFlow — Next.js + Supabase E-Commerce

A production-ready e-commerce platform built with **Next.js 15 (App Router)**, **Supabase**, **React**, and **Tailwind CSS**.

---

## Quick Start

```bash
npm install
npm run dev   # http://localhost:3000
```

`.env.local` is pre-configured with the provided Supabase credentials.

---

## Supabase Setup (one-time)

1. Open your **Supabase Studio → SQL Editor**
2. Paste the entire contents of `supabase_schema.sql` and run it
3. This creates all tables, RLS policies, indexes, and the auto-profile trigger
4. To make a user an admin, run:
   ```sql
   UPDATE public.profiles SET role = 'admin' WHERE id = '<user-uuid>';
   ```
   You can find a user's UUID in **Studio → Auth → Users**.

---

## Project Structure

```
├── .env.local                          # Supabase env vars (NEXT_PUBLIC_ only)
├── next.config.ts                      # Next.js config (image domains, server actions)
├── tsconfig.json                       # TypeScript with path aliases (@/*)
├── supabase_schema.sql                 # Full DB schema + RLS (run once in Studio)
│
└── src/
    ├── app/
    │   ├── layout.tsx                  # Root layout (CartProvider, fonts, globals)
    │   ├── (main)/                     # Route group — shared Navbar + Footer layout
    │   │   ├── layout.tsx
    │   │   ├── page.tsx                # Home — hero + product grid
    │   │   ├── products/page.tsx       # Full product listing with filters
    │   │   ├── product/[id]/page.tsx   # Dynamic product detail
    │   │   ├── cart/page.tsx           # Shopping cart
    │   │   ├── checkout/page.tsx       # Checkout (COD / UPI)
    │   │   └── orders/page.tsx         # Order history
    │   ├── auth/
    │   │   ├── login/page.tsx          # Login page
    │   │   └── signup/page.tsx         # Sign-up page
    │   ├── admin/                      # Admin panel (protected by middleware)
    │   │   ├── layout.tsx              # Admin topbar
    │   │   ├── products/page.tsx       # Admin product listing
    │   │   └── product/[id]/page.tsx   # Add / Edit product form
    │   └── api/
    │       └── checkout/
    │           └── validate/route.ts   # POST — server-side stock + total validation
    │
    ├── components/
    │   ├── layout/   Navbar.tsx, Footer.tsx
    │   ├── product/  ProductCard.tsx, ProductDetailClient.tsx, ProductsClient.tsx
    │   ├── cart/     CartPageClient.tsx
    │   ├── checkout/ CheckoutClient.tsx, OrderHistory.tsx
    │   ├── auth/     LoginForm.tsx, SignUpForm.tsx
    │   └── admin/    AdminProductsClient.tsx, AdminProductForm.tsx
    │
    ├── context/
    │   └── CartContext.tsx             # Cart state (useReducer + localStorage)
    │
    ├── hooks/
    │   └── useAuth.ts                  # Auth hook (session, signIn, signUp, signOut)
    │
    ├── lib/
    │   └── supabase.ts                 # Browser + Server Supabase client factories
    │
    ├── middleware.ts                    # Route guards (auth, admin, redirects)
    │
    ├── types/
    │   └── supabase.ts                 # TypeScript types for all tables + cart
    │
    └── styles/
        └── globals.css                 # Tailwind import + CSS variables + scrollbar
```

---

## Security Model

| Layer | What it does |
|---|---|
| **Environment variables** | Only `NEXT_PUBLIC_` keys are used — no service role key ever touches the frontend |
| **RLS policies** | Products are publicly readable; orders and order_items are scoped to `auth.uid()` |
| **Middleware** | Guards `/cart`, `/checkout`, `/orders` (must be logged in) and `/admin` (must have `role = admin`) |
| **API route** | `/api/checkout/validate` re-checks stock and recalculates totals server-side — client totals are never trusted |
| **WITH CHECK constraints** | RLS `WITH CHECK` clauses prevent users from inserting orders or items belonging to other users |

---

## Key Design Decisions

- **Server Components for data fetching** — product listings and order history are rendered server-side for SEO and performance.  
- **Client Components only where interactivity is needed** — cart mutations, form submissions, quantity controls.  
- **Cart persisted in localStorage** — no extra DB round-trip for cart state; validated server-side at checkout.  
- **Route group `(main)`** — shares Navbar + Footer layout without affecting URL structure.  
- **Single dynamic route for admin create/edit** — `/admin/product/new` creates; `/admin/product/<uuid>` edits.
