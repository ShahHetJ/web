-- ============================================================================
-- ShopFlow — Supabase Schema & RLS Policies
-- Run this in your Supabase SQL Editor (Studio → SQL Editor)
-- ============================================================================

-- ─── 1. Enable extensions ────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;

-- ─── 2. Profiles table (mirrors auth.users, stores app-specific role) ────────
CREATE TABLE IF NOT EXISTS public.profiles (
  id        uuid        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text        NOT NULL DEFAULT '',
  role      text        NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Auto-create profile on sign-up (trigger on auth.users insert)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ─── 3. Products table ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.products (
  id          uuid        PRIMARY KEY DEFAULT extensions.uuid_generate_v4(),
  name        text        NOT NULL,
  description text        NOT NULL DEFAULT '',
  price       numeric(10,2) NOT NULL CHECK (price >= 0),
  stock       integer     NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image_url   text,
  category    text        NOT NULL DEFAULT 'General',
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- ─── 4. Orders table ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.orders (
  id           uuid        PRIMARY KEY DEFAULT extensions.uuid_generate_v4(),
  user_id      uuid        NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  total_amount numeric(12,2) NOT NULL CHECK (total_amount >= 0),
  status       text        NOT NULL DEFAULT 'pending'
                            CHECK (status IN ('pending','confirmed','shipped','delivered')),
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── 5. Order items table ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.order_items (
  id         uuid    PRIMARY KEY DEFAULT extensions.uuid_generate_v4(),
  order_id   uuid    NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid    NOT NULL REFERENCES public.products(id) ON DELETE SET NULL,
  quantity   integer NOT NULL CHECK (quantity > 0),
  price      numeric(10,2) NOT NULL CHECK (price >= 0)
);

-- ─── 6. Indexes for common queries ────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_orders_user_id      ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status       ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order   ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON public.order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_products_category   ON public.products(category);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- ─── Profiles ─────────────────────────────────────────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Users can read their own profile
CREATE POLICY "profiles: read own"
  ON public.profiles FOR SELECT
  USING (id = auth.uid());

-- Users can update their own profile
CREATE POLICY "profiles: update own"
  ON public.profiles FOR UPDATE
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- ─── Products ─────────────────────────────────────────────────────────────────
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- PUBLIC READ: anyone (including anonymous) can read all products
CREATE POLICY "products: public read"
  ON public.products FOR SELECT
  USING (true);

-- ADMIN ONLY: insert, update, delete
CREATE POLICY "products: admin insert"
  ON public.products FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "products: admin update"
  ON public.products FOR UPDATE
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "products: admin delete"
  ON public.products FOR DELETE
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── Orders ───────────────────────────────────────────────────────────────────
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Users can only read their OWN orders
CREATE POLICY "orders: read own"
  ON public.orders FOR SELECT
  USING (user_id = auth.uid());

-- Users can insert orders (user_id enforced via WITH CHECK)
CREATE POLICY "orders: insert own"
  ON public.orders FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Users can update status on their own orders (status transitions handled app-side)
CREATE POLICY "orders: update own"
  ON public.orders FOR UPDATE
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Admins can read ALL orders
CREATE POLICY "orders: admin read all"
  ON public.orders FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Admins can update any order (e.g. change status to confirmed/shipped/delivered)
CREATE POLICY "orders: admin update all"
  ON public.orders FOR UPDATE
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── Order Items ──────────────────────────────────────────────────────────────
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- Users can read items belonging to their own orders
CREATE POLICY "order_items: read own"
  ON public.order_items FOR SELECT
  USING (
    order_id IN (SELECT id FROM public.orders WHERE user_id = auth.uid())
  );

-- Users can insert items into their own orders
CREATE POLICY "order_items: insert own"
  ON public.order_items FOR INSERT
  WITH CHECK (
    order_id IN (SELECT id FROM public.orders WHERE user_id = auth.uid())
  );

-- Admins can read all order items
CREATE POLICY "order_items: admin read all"
  ON public.order_items FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ============================================================================
-- PROMOTE A USER TO ADMIN (run manually when needed)
-- Replace <user-uuid> with the actual auth.users id
-- ============================================================================
-- UPDATE public.profiles SET role = 'admin' WHERE id = '<user-uuid>';
